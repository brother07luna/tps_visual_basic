﻿Public Class Form1
    'Realizar el siguiente proyecto: "Adivina el número"
    'A el usuario se le pide que, mediante el ingreso de números, según sea su estrategia, 
    'adivinar el número generado en forma aleatoria. 
    'Para dicha resolución el usuario tendrá 
    '10 intentos. En los intentos tendrá tres posibles mensajes, 
    '"Es mayor el numero que buscas", "Es menor el numero que buscas" o "Adivinaste el número".
    'Generar un número al azar entre 0 y 50 (Muy aleatorio) y guardarlo en un lugar acorde y lógico para luego usarlo.
    'Generar un lugar acorde para guardar y usar un contador que no requiere más que llegar a diez (10).
    'La aplicación deberá tener un grafico progressbar para ir mostrando los intentos 
    'y las pseudo vidas que le queda al usuario.
    'En una Label deberá ir mostrando los números probados-ingresados 
    'por el usuario separados por un guion medio, Ejemplo (23-14-44-45- etc...)
    'Usar un picturebox que tenga una imagen acorde cuando gana y otra cuando pierde,
    'después de los 10 intentos, y mostrar el numero aleatorio guardado. (Ser creativo con
    'las herramientas que cuenta la pс).
    'La aplicación tiene que tener todo lo necesario y más.... (Labels, Textbox, focus, tooltip etc...)
    'Ser creativo es fundamental, use las herramientas usadas en los trabajos anteriores.


End Class
