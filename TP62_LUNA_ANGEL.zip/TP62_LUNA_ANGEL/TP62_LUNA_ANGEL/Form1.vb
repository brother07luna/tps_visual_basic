﻿Public Class Form1
    Dim centesimos As Integer = 0
    Dim segundos As Integer = 0
    Dim minutos As Integer = 0
    Dim andando As Boolean = False

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        If andando Then
            centesimos += 1

            If centesimos = 100 Then
                centesimos = 0
                segundos += 1

                If segundos = 60 Then
                    segundos = 0
                    minutos += 1

                    If minutos = 60 Then
                        minutos = 0
                    End If
                End If
            End If

            Label1.Text = minutos.ToString("00") & ":" & segundos.ToString("00") & ":" & centesimos.ToString("00")
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        andando = True
        Timer1.Interval = 10
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        andando = False
    End Sub

    Private Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        andando = False
        centesimos = 0
        segundos = 0
        minutos = 0
        Label1.Text = "00:00:00"
    End Sub

    Private Sub Button4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
        
        ListBox1.Items.Add(Label1.Text)
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Label1.Text = "00:00:00"
    End Sub
End Class
