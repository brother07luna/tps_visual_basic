﻿Public Class Form1
    Dim resultado As Double = 0 ' Puse Double por si se hace división'
    Dim primerOper As Boolean = True

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim num1 As Double = Val(TextBox1.Text)
        If primerOper Then
            resultado = num1
            primerOper = False
        Else
            resultado = resultado + num1
        End If
        Label1.Text = resultado
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim num1 As Double = Val(TextBox1.Text)
        If primerOper Then
            resultado = num1
            primerOper = False
        Else
            resultado = resultado - num1
        End If
        Label1.Text = resultado
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim num1 As Double = Val(TextBox1.Text)
        If primerOper Then
            resultado = num1
            primerOper = False
        Else
            resultado = resultado * num1
        End If
        Label1.Text = resultado
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim num1 As Double = Val(TextBox1.Text)
        If primerOper Then
            resultado = num1
            primerOper = False
        Else
            If num1 <> 0 Then
                resultado = resultado / num1
            Else
                Label1.Text = "Error: División por cero"
                Exit Sub
            End If
        End If
        Label1.Text = resultado
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = ""
        Label1.Text = ""
        resultado = 0
        primerOper = True
    End Sub
End Class
