﻿Public Class Form1
    'Realizar el siguiente proyecto: "Adivina el número"
    'A el usuario se le pide que, mediante el ingreso de números, según sea su estrategia, 
    'adivinar el número generado en forma aleatoria. 
    'Para dicha resolución el usuario tendrá 
    '10 intentos. En los intentos tendrá tres posibles mensajes, 
    '"Es mayor el numero que buscas", "Es menor el numero que buscas" o "Adivinaste el número".
    'Generar un número al azar entre 0 y 50 (Muy aleatorio) y guardarlo en un lugar acorde y lógico para luego usarlo.
    'Generar un lugar acorde para guardar y usar un contador que no requiere más que llegar a diez (10).
    'La aplicación deberá tener un grafico progressbar para ir mostrando los intentos 
    'y las pseudo vidas que le queda al usuario.
    'En una Label deberá ir mostrando los números probados-ingresados 
    'por el usuario separados por un guion medio, Ejemplo (23-14-44-45- etc...)
    'Usar un picturebox que tenga una imagen acorde cuando gana y otra cuando pierde,
    'después de los 10 intentos, y mostrar el numero aleatorio guardado. (Ser creativo con
    'las herramientas que cuenta la pс).
    'La aplicación tiene que tener todo lo necesario y más.... (Labels, Textbox, focus, tooltip etc...)
    'Ser creativo es fundamental, use las herramientas usadas en los trabajos anteriores.

    Dim numeroSecreto As Integer
    Dim intentos As Integer = 0
    Dim historial As String = ""
    Dim juegoActivo As Boolean = True
    

    Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        Randomize()
        numeroSecreto = Int(Rnd() * 51) ' Número aleatorio entre 0 y 50
        ProgressBar1.Maximum = 10
        ProgressBar1.Minimum = 0
        ProgressBar1.Value = 0

        Label1.Text = "Ingresá un número entre 0 y 50"
        Label2.Text = "Intentos: "
        PictureBox1.Visible = False

        ToolTip1.SetToolTip(TextBox1, "Escribí un número entre 0 y 50")
        ToolTip1.SetToolTip(Button1, "Presioná para adivinar el número")


    End Sub

    Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        If juegoActivo Then

            If IsNumeric(TextBox1.Text) And TextBox1.Text <> "" Then
                Dim intento As Integer = Val(TextBox1.Text)

                If intento >= 0 And intento <= 50 Then
                    intentos = intentos + 1
                    ProgressBar1.Value = intentos
                    historial = historial & intento.ToString() & "-"
                    Label2.Text = "Intentos: " & historial

                    If intento = numeroSecreto Then
                        Label1.Text = "¡Adivinaste el número!"

                        PictureBox1.Visible = True
                        juegoActivo = False

                    ElseIf intento < numeroSecreto Then
                        Label1.Text = "El número que buscás es mayor."

                    ElseIf intento > numeroSecreto Then
                        Label1.Text = "El número que buscás es menor."
                    End If

                    If intentos = 10 And intento <> numeroSecreto Then
                        juegoActivo = False
                        Label1.Text = "Perdiste. El número era: " & numeroSecreto

                        PictureBox2.Visible = True
                    End If

                Else
                    Label1.Text = "Debe ser un número entre 0 y 50."
                End If
            Else
                Label1.Text = "Por favor, ingresá un número válido."
            End If

            TextBox1.Text = ""

        Else
            Label1.Text = "El juego terminó. Reiniciá para volver a jugar."
        End If
    End Sub

    Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        numeroSecreto = Int(Rnd() * 51)
        intentos = 0
        historial = ""
        juegoActivo = True
        ProgressBar1.Value = 0
        Label1.Text = "Ingresá un número entre 0 y 50"
        Label2.Text = "Intentos: "
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        TextBox1.Text = ""

        TextBox1.Focus()
    End Sub

    
End Class
