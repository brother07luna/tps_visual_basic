﻿Public Class Form1
    Dim prom As Double
    Dim a, b, c, d As Double
    Dim todook As Boolean = True
    Dim err As String = ""
    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Not IsNumeric(TextBox1.Text) Or TextBox1.Text = "" Then
            Label1.Text = "Error: Ingrese un numero valido"
            todook = False
        ElseIf Not IsNumeric(TextBox1.Text) Or TextBox1.Text = "" Then
            Label1.Text = "Error: Ingrese un numero valido"
            todook = False
        ElseIf Not IsNumeric(TextBox2.Text) Or TextBox2.Text = "" Then
            Label1.Text = "Error: Ingrese un numero valido"
            todook = False
        ElseIf Not IsNumeric(TextBox3.Text) Or TextBox3.Text = "" Then
            Label1.Text = "Error: Ingrese un numero valido"
            todook = False
        End If
        If todook = True Then
            a = Val(TextBox1.Text)
            b = Val(TextBox2.Text)
            c = Val(TextBox3.Text)
            d = Val(TextBox4.Text)

            If a > 10 Or b > 10 Or c > 10 Or d > 10 Then
                err = "Error las notas:no pueden ser mayores a 10"
                todook = False
            End If
        End If




        If todook = True Then
            prom = (a + b + c + d) / 4
            If prom >= 6 Then
                Label1.Text = "Aprobado: promedio: " & prom
            ElseIf prom = 5 Or prom = 6 Then
                Label1.Text = "Va directo a Diciembre: Promedio:" & prom
            ElseIf prom < 5 Then
                Label1.Text = "Va a marzo : su promedio: " & prom

            End If
        Else
            Label1.Text = err
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label1.Text = ""

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub


    
End Class
