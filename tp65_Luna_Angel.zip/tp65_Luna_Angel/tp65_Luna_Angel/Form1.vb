﻿Public Class Form1
    Dim estado As Integer = 0
    Dim parpadeo As Boolean = False

    Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        PictureBox1.Visible = False ' Rojo
        PictureBox2.Visible = False ' Amarillo
        PictureBox3.Visible = False ' Verde
        Timer1.Enabled = False
        Timer2.Enabled = False
    End Sub

    Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        estado = 0
        Timer1.Interval = 1
        Timer1.Start()
        Timer2.Stop()
    End Sub

    Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        Timer1.Stop()
        Timer2.Stop()
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        PictureBox3.Visible = False
    End Sub

    Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        Timer1.Stop()
        Timer2.Interval = 1500
        Timer2.Start()
    End Sub

    Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        If estado = 0 Then
            PictureBox1.Visible = True
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            Timer1.Interval = 3000
            estado = 1

        ElseIf estado = 1 Then
            PictureBox1.Visible = True
            PictureBox2.Visible = True
            PictureBox3.Visible = False
            Timer1.Interval = 1500
            estado = 2

        ElseIf estado = 2 Then
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = True
            Timer1.Interval = 3000
            estado = 0

        End If
    End Sub

    Sub Timer2_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer2.Tick
        ' Parpadeo amarillo ON/OFF
        If parpadeo = False Then
            PictureBox1.Visible = False
            PictureBox2.Visible = True
            PictureBox3.Visible = False
            parpadeo = True
        Else
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            parpadeo = False
        End If
    End Sub

End Class

